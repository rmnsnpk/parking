export const JWT_CONSTANTS = {
  secret: 'secretKey',
  expiresIn: 50000,
};
