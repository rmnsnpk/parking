export enum UserDBKeys {
  NAME = 'name',
}
