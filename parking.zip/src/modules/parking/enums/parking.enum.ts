export enum ParkingDBKeys {
  ID = 'slotNumber',
  LICENSE = 'license',
  IS_EMPTY = 'isEmpty',
}
